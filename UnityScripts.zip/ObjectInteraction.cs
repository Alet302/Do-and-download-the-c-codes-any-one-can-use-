
using UnityEngine;

public class ObjectInteraction : MonoBehaviour
{
    public float interactionDistance = 2f;
    public LayerMask interactableLayer;

    void Update()
    {
        if (Input.GetKeyDown(KeyCode.E))
        {
            RaycastHit hit;
            if (Physics.Raycast(transform.position, transform.forward, out hit, interactionDistance, interactableLayer))
            {
                hit.collider.GetComponent<IInteractable>()?.Interact();
            }
        }
    }
}

public interface IInteractable
{
    void Interact();
}
