
using UnityEngine;

public class EnemyAI : MonoBehaviour
{
    public Transform player;
    public float chaseRange = 10f;
    public float attackRange = 2f;
    public float moveSpeed = 2f;

    void Update()
    {
        float distanceToPlayer = Vector3.Distance(transform.position, player.position);

        if (distanceToPlayer <= chaseRange)
        {
            Vector3 direction = (player.position - transform.position).normalized;
            if (distanceToPlayer > attackRange)
            {
                transform.position += direction * moveSpeed * Time.deltaTime;
            }
            else
            {
                AttackPlayer();
            }
        }
    }

    void AttackPlayer()
    {
        // Implement attack behavior
    }
}
