
using UnityEngine;

public class PlayerCrouch : MonoBehaviour
{
    public float crouchHeight = 1f;
    public float normalHeight = 2f;
    private CharacterController characterController;

    void Start()
    {
        characterController = GetComponent<CharacterController>();
    }

    void Update()
    {
        if (Input.GetKeyDown(KeyCode.C))
        {
            characterController.height = crouchHeight;
        }
        if (Input.GetKeyUp(KeyCode.C))
        {
            characterController.height = normalHeight;
        }
    }
}
