
using UnityEngine;

public class Inventory : MonoBehaviour
{
    public int[] items;

    public void AddItem(int itemID)
    {
        // Implement adding item to inventory
    }
}
