
using UnityEngine;

public class PlayerSprint : MonoBehaviour
{
    public float walkSpeed = 5f;
    public float sprintSpeed = 10f;
    private CharacterController characterController;

    void Start()
    {
        characterController = GetComponent<CharacterController>();
    }

    void Update()
    {
        float speed = Input.GetKey(KeyCode.LeftShift) ? sprintSpeed : walkSpeed;
        float moveDirectionY = characterController.velocity.y;

        Vector3 move = transform.right * Input.GetAxis("Horizontal") + transform.forward * Input.GetAxis("Vertical");
        characterController.Move(move * speed * Time.deltaTime);
        characterController.Move(Vector3.up * moveDirectionY * Time.deltaTime);
    }
}
