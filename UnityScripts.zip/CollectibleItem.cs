
using UnityEngine;

public class CollectibleItem : MonoBehaviour
{
    public int itemID;

    void OnTriggerEnter(Collider other)
    {
        if (other.CompareTag("Player"))
        {
            other.GetComponent<Inventory>().AddItem(itemID);
            Destroy(gameObject);
        }
    }
}
