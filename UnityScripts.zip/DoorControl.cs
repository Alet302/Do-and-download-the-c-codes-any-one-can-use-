
using UnityEngine;

public class DoorControl : MonoBehaviour, IInteractable
{
    public Animator doorAnimator;

    public void Interact()
    {
        doorAnimator.SetTrigger("Open");
    }
}
